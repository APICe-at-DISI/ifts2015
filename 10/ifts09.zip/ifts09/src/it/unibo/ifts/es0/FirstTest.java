package it.unibo.ifts.es0;

public class FirstTest {

	public static void main(String[] args) {
		for (int i  = 0; i < 200; i++) {
			System.out.println(i);
		}
	}

}
