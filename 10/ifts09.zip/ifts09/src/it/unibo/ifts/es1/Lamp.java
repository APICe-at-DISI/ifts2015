package it.unibo.ifts.es1;

public interface Lamp {
	
	void switchOn();
	
	void switchOff();
	
	boolean isOn();

}
