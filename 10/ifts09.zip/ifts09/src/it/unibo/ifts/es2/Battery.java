package it.unibo.ifts.es2;

public interface Battery {

	boolean isCharged();
	
	void discharge(int quantity);
	
}
