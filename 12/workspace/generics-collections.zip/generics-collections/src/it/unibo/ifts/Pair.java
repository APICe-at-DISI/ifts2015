package it.unibo.ifts;

public interface Pair<Z, K> {
	
	Z getFirst();
	
	K getSecond();

}
