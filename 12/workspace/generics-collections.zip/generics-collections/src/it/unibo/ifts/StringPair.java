package it.unibo.ifts;

public class StringPair extends PairImpl<String, String> {
	
	public StringPair(String a, String b) {
		super(a, b);
	}

}
