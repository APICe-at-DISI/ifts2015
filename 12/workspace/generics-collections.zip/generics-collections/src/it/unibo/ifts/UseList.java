package it.unibo.ifts;

public class UseList {

	public static void main(String[] args) {
		
		final IntList l = new IntList();
		l.add(1);
		l.add(2);
		l.add(1561);
		System.out.println(l);
		System.out.println(l.get(0));
	}

}
